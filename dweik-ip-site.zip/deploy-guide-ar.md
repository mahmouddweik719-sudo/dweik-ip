# دليل نشر موقع DWEIK IP مجاناً وظهوره على جوجل

## الملفات
- `index.html` — الموقع (ملف واحد، بدون أي مكتبات خارجية تتعطل مع الوقت)
- `logo-mark.svg` — أيقونة الشعار (تُستخدم كـ favicon)
- `logo-full.svg` — الشعار الكامل (أفقي)
- `robots.txt` و `sitemap.xml` — لمحركات البحث

## الخطوة 1: النشر المجاني (اختر واحدة)

### الخيار الأفضل: GitHub Pages (مجاني ودائم)
1. اعمل حساب على github.com (مجاني).
2. New repository → اسمه مثلاً `dweik-ip` → Public.
3. Add file → Upload files → ارفع الملفات الخمسة → Commit.
4. Settings → Pages → Source: `Deploy from a branch` → Branch: `main` / `(root)` → Save.
5. بعد دقيقة أو اثنتين رابطك يكون: `https://اسم-حسابك.github.io/dweik-ip/`

### بديل: Cloudflare Pages أو Netlify
- Netlify: ادخل على app.netlify.com/drop واسحب مجلد الملفات، وتاخد رابط `xxxx.netlify.app` فوراً.
- Cloudflare Pages: رابط بصيغة `xxxx.pages.dev`.

## الخطوة 2: استبدل الرابط
بعد ما يظهر رابطك الحقيقي، افتح الملفات التالية واعمل Find & Replace للنص `YOUR-SITE-URL` برابطك (بدون https://):
`index.html` و `robots.txt` و `sitemap.xml`
مثال: `اسم-حسابك.github.io/dweik-ip`
ثم ارفع الملفات المعدلة تاني.

## الخطوة 3: الظهور على جوجل
1. ادخل search.google.com/search-console بحساب Gmail.
2. Add property → **URL prefix** → الصق رابط موقعك.
3. التحقق: اختر طريقة HTML tag، وانسخ الـ meta tag وحطه داخل `<head>` في `index.html` وارفع الملف، ثم اضغط Verify.
4. من Sitemaps أضف: `sitemap.xml`
5. من URL Inspection الصق رابط الصفحة الرئيسية واضغط **Request indexing**.

## ملاحظات مهمة وصريحة
- جوجل يبدأ يفهرس الموقع عادةً خلال أيام لأسابيع، **ولا يوجد أي أداة تضمن مركزاً معيناً**. الترتيب بيعتمد على المنافسة والمحتوى والروابط.
- بدون دومين، الرابط سيكون ضمن موقع الاستضافة (github.io مثلاً) وده مقبول لجوجل، لكن الدومين الخاص (حوالي 10–15 دولار سنوياً) أقوى للثقة والترتيب. تقدر تضيفه لاحقاً بدون تغيير الموقع.
- لزيادة الظهور مجاناً: أنشئ **Google Business Profile** للمكتب (يظهر في الخرائط والبحث المحلي)، وصفحات على LinkedIn وفيسبوك، وضع رابط الموقع فيها كلها.
- أي نموذج على الموقع يفتح واتساب برسالة جاهزة، يعني الطلبات تصلك مباشرة على رقمك بدون خادم أو اشتراك.
